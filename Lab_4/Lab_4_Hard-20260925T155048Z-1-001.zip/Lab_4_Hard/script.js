// Задача: форма регистрации с индикатором корректности 
// Поля: логин, e-mail, пароль, подтверждение пароля.
// Валидация выполняется и при вводе (input), и при отправке (submit).

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registration-form");
  const successMessage = document.getElementById("form-success");

  if (!form) return;

  const loginInput = document.getElementById("login");
  const emailInput = document.getElementById("reg-email");
  const passwordInput = document.getElementById("password");
  const confirmInput = document.getElementById("password-confirm");


  const fields = {
    login: {
      input: loginInput,
      icon: document.getElementById("login-icon"),
      error: document.getElementById("login-error"),
      validate: (value) => /^[a-zA-Z0-9_]{3,}$/.test(value.trim()),
      message: "Логин: минимум 3 символа, только буквы, цифры.",
    },
    email: {
      input: emailInput,
      icon: document.getElementById("reg-email-icon"),
      error: document.getElementById("reg-email-error"),
      validate: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()),
      message: "Введите корректный e-mail.",
    },
    password: {
      input: passwordInput,
      icon: document.getElementById("password-icon"),
      error: document.getElementById("password-error"),
      validate: (value) => /^(?=.*[A-Za-z])(?=.*\d).{6,}$/.test(value),
      message: "Пароль: минимум 6 символов, буква и цифра.",
    },
    confirm: {
      input: confirmInput,
      icon: document.getElementById("password-confirm-icon"),
      error: document.getElementById("password-confirm-error"),
      validate: (value) => value.length > 0 && value === passwordInput.value,
      message: "Пароли не совпадают.",
    },
  };

  function setStatus(field, isValid, hasValue) {
    const { input, icon, error, message } = field;

    input.classList.remove("valid", "invalid");
    icon.classList.remove("valid", "invalid");
    icon.textContent = "";

    if (!hasValue) {
    
      error.textContent = "";
      return;
    }

    if (isValid) {
      input.classList.add("valid");
      icon.classList.add("valid");
      icon.textContent = "✓";
      error.textContent = "";
    } else {
      input.classList.add("invalid");
      icon.classList.add("invalid");
      icon.textContent = "✕";
      error.textContent = message;
    }
  }

  function validateField(field, forceShow = false) {
    const value = field.input.value;
    const hasValue = value.length > 0 || forceShow;
    const isValid = field.validate(value);
    setStatus(field, isValid, hasValue);
    return isValid;
  }

  Object.values(fields).forEach((field) => {
    field.input.addEventListener("input", () => {
      validateField(field);
      
      if (field === fields.password && fields.confirm.input.value.length > 0) {
        validateField(fields.confirm);
      }
    });
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    successMessage.classList.remove("show");

    let isFormValid = true;
    Object.values(fields).forEach((field) => {
      const valid = validateField(field, true); 
      if (!valid) isFormValid = false;
    });

    if (isFormValid) {
      successMessage.classList.add("show");
      form.reset();
      Object.values(fields).forEach((field) => {
        field.input.classList.remove("valid", "invalid");
        field.icon.classList.remove("valid", "invalid");
        field.icon.textContent = "";
        field.error.textContent = "";
      });
    } else {
      const firstInvalid = form.querySelector(".invalid");
      if (firstInvalid) firstInvalid.focus();
    }
  });
});