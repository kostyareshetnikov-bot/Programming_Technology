// Задача: форма расчёта доставки
// Проверка: город и тип доставки заполнены, вес — положительное число.
// После успешной проверки выводим выбранные данные.

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("delivery-form");
  const resultBox = document.getElementById("form-result");

  if (!form) return;

  const fields = {
    city: {
      input: document.getElementById("city"),
      error: document.getElementById("city-error"),
      validate: (value) => value.trim().length > 0,
      message: "Укажите город.",
    },
    weight: {
      input: document.getElementById("weight"),
      error: document.getElementById("weight-error"),
      validate: (value) => {
        const num = parseFloat(value);
        return value.trim() !== "" && !isNaN(num) && num > 0;
      },
      message: "Вес должен быть положительным числом.",
    },
    "delivery-type": {
      input: document.getElementById("delivery-type"),
      error: document.getElementById("delivery-type-error"),
      validate: (value) => value !== "",
      message: "Выберите тип доставки.",
    },
  };

  function validateField(field) {
    const { input, error, validate, message } = field;
    const isValid = validate(input.value);

    if (isValid) {
      input.classList.remove("invalid");
      error.textContent = "";
    } else {
      input.classList.add("invalid");
      error.textContent = message;
    }

    return isValid;
  }

  Object.values(fields).forEach((field) => {
    const eventType = field.input.tagName === "SELECT" ? "change" : "input";
    field.input.addEventListener(eventType, () => validateField(field));
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    resultBox.classList.remove("show");
    resultBox.innerHTML = "";

    let isFormValid = true;
    Object.values(fields).forEach((field) => {
      if (!validateField(field)) isFormValid = false;
    });

    if (!isFormValid) {
      const firstInvalid = form.querySelector(".invalid");
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    const city = fields.city.input.value.trim();
    const weight = parseFloat(fields.weight.input.value);
    const deliveryType = fields["delivery-type"].input.value;

    resultBox.innerHTML = `
      <p><strong>Данные для расчёта приняты:</strong></p>
      <ul>
        <li>Город: ${city}</li>
        <li>Вес посылки: ${weight} кг</li>
        <li>Тип доставки: ${deliveryType}</li>
      </ul>
    `;
    resultBox.classList.add("show");
  });
});